package ex2.dados;

public class Quadrados {
    
}
