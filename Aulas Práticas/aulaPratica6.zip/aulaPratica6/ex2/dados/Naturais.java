package ex2.dados;

public class Naturais {
    
}
