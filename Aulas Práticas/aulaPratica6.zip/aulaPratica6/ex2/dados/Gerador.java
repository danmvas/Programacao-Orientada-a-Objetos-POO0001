package ex2.dados;

public abstract class Gerador {

    public int gerar(int num);
    
}
