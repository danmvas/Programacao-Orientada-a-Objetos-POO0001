package ex1;

public enum Grupo {

    /*numero do grupo o qual a pessoa pertence
    0: 0-12
    1: 13-18
    2: 19-25
    3: 26-59
    4: 60+
    */

    CRIANCAS, ADOLESCENTES, JOVENS, ADULTOS, IDOSOS;
    
}
