package ex2ex3;

public enum Quadrante {

    PRIMEIRO, SEGUNDO, TERCEIRO, QUARTO;

}
