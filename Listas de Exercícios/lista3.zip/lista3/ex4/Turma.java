package ex4;
import java.util.ArrayList;

public class Turma {
    
    private ArrayList<Aluno> aluno = new ArrayList<>();


    public void adicionaNovoAluno(Aluno aluno){


    }

    public void ordenarAlunosPorMedia(){

    }

    public void separarEmEquipes(){
        //agrupar alunos pegando um ou dois elementos do começo da lista ordenada por média
        //e um ou dois alunos do final da lista

        
    }



}
